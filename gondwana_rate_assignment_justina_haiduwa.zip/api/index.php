<?php
require_once __DIR__ . '/RateService.php';
require_once __DIR__ . '/helpers.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

if ($path === '/rates' && $method === 'POST') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        respond_json(['error' => 'Invalid JSON payload'], 400);
    }
    try {
        $svc = new RateService();
        $transformed = $svc->ingestPayload($data);
        $remoteResponse = $svc->fetchRates($transformed);
        $response = [
            'Unit Name' => $data['Unit Name'],
            'Date Range' => [ 'Arrival' => $transformed['Arrival'], 'Departure' => $transformed['Departure'] ],
            'TransformedPayload' => $transformed,
            'Remote' => $remoteResponse
        ];
        respond_json($response, 200);
    } catch (Exception $e) {
        respond_json(['error' => $e->getMessage()], 400);
    }
}

respond_json(['message' => 'Welcome to the Rates API. Use POST /rates with the assignment payload.']);

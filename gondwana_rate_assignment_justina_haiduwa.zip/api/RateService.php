<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';

class RateService {
    private $remoteUrl;
    private $unitIds;

    public function __construct() {
        $this->remoteUrl = getenv('REMOTE_API_URL');
        $this->unitIds = get_unit_ids();
    }

    public function ingestPayload($payload) {
        if (!is_array($payload)) throw new Exception('Payload must be JSON object');
        $required = ['Unit Name', 'Arrival', 'Departure', 'Occupants', 'Ages'];
        foreach ($required as $r) {
            if (!array_key_exists($r, $payload)) throw new Exception('Missing ' . $r);
        }
        $arrival = parse_ddmmyyyy_to_yyyy_mm_dd($payload['Arrival']);
        $departure = parse_ddmmyyyy_to_yyyy_mm_dd($payload['Departure']);
        if (!$arrival || !$departure) throw new Exception('Invalid date format; expected dd/mm/yyyy');
        if (!is_array($payload['Ages'])) throw new Exception('Ages must be an array of integers');
        $unitTypeId = $this->unitIds[0] ?? null;
        if ($unitTypeId === null) throw new Exception('No Unit Type ID configured');

        $guests = [];
        foreach ($payload['Ages'] as $age) {
            $guests[] = ['Age Group' => age_to_agegroup($age)];
        }

        $transformed = [
            'Unit Type ID' => (int)$unitTypeId,
            'Arrival' => $arrival,
            'Departure' => $departure,
            'Guests' => $guests
        ];

        return $transformed;
    }

    public function fetchRates($transformedPayload) {
        $result = http_post_json($this->remoteUrl, $transformedPayload);
        if (!$result['ok']) {
            throw new Exception('Failed to reach remote API: ' . $result['error']);
        }
        $body = $result['body'];
        $decoded = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['raw' => $body, 'http_code' => $result['http_code']];
        }
        return $decoded;
    }
}

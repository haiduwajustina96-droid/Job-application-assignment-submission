<?php

function respond_json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function parse_ddmmyyyy_to_yyyy_mm_dd($dateStr) {
    // Accept dd/mm/yyyy or d/m/yyyy
    $parts = preg_split('#[\/\-]#', trim($dateStr));
    if (count($parts) !== 3) return null;
    list($d, $m, $y) = $parts;
    $d = str_pad($d, 2, '0', STR_PAD_LEFT);
    $m = str_pad($m, 2, '0', STR_PAD_LEFT);
    if (!checkdate((int)$m, (int)$d, (int)$y)) return null;
    return sprintf('%04d-%02d-%02d', (int)$y, (int)$m, (int)$d);
}

function age_to_agegroup($age) {
    return ((int)$age >= 18) ? 'Adult' : 'Child';
}

function http_post_json($url, $data, $headers = []) {
    $ch = curl_init($url);
    $payload = json_encode($data);
    $defaultHeaders = [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($payload)
    ];
    $allHeaders = array_merge($defaultHeaders, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $allHeaders);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $errmsg = curl_error($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [
        'ok' => ($errno === 0),
        'errno' => $errno,
        'error' => $errmsg,
        'http_code' => $httpcode,
        'body' => $response
    ];
}

<?php
// Simple config loader
$envPath = __DIR__ . '/../.env';
if (file_exists($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') === false) continue;
        list($k, $v) = explode('=', $line, 2);
        putenv(trim($k) . '=' . trim($v));
    }
}

// Defaults
if (!getenv('REMOTE_API_URL')) {
    putenv('REMOTE_API_URL=https://dev.gondwana-collection.com/Web-Store/Rates/Rates.php');
}
if (!getenv('UNIT_TYPE_IDS')) {
    putenv('UNIT_TYPE_IDS=-2147483637,-2147483456');
}

// Helper: get unit IDs array
function get_unit_ids() {
    return array_map('intval', array_map('trim', explode(',', getenv('UNIT_TYPE_IDS'))));
}

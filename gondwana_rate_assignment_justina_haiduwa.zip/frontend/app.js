const form = document.getElementById('rateForm');
const output = document.getElementById('output');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  const payload = {
    'Unit Name': fd.get('Unit Name'),
    'Arrival': fd.get('Arrival'),
    'Departure': fd.get('Departure'),
    'Occupants': parseInt(fd.get('Occupants'), 10) || 1,
    'Ages': fd.get('Ages') ? fd.get('Ages').split(',').map(s => parseInt(s.trim(),10)) : []
  };

  output.textContent = 'Requesting...';
  try {
    const res = await fetch('/rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    output.textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    output.textContent = 'Error: ' + err.message;
  }
});
